
import logger_class
import os 
from collections import Counter
x = logger_class.log(os.path.abspath(__name__))
lg = x.get_logger()

class file_opertion:
    
    def __init__(self, file_name):
        
        if os.path.isfile(file_name):
            self.file_name = file_name
            lg.debug("file_name is %s" % self.file_name)
        else:
            lg.error("file_name is not exist")
            raise Exception("file_name is not exist")
            
    
    def file_to_list(self):
        """This function takes a file name as input and 
    returns a list of lines from the file."""
        lg.debug("file_to_list is called")
        lg.debug("file_name is %s" % self.file_name)
        try:
            with open(self.file_name) as f:
                result = f.read().splitlines()
                lg.debug("result is %s" % result)
                return result
        except Exception as e:
            lg.error("Exception is %s" % e)
    def alpha_counter(self,alpha):
        """This function takes a list as input and 
        returns a dictionary with the count of each first letter of the word
        in the list."""
        lg.debug("alpha_counter is called")
        lg.debug("alpha is %s" % alpha)
        mapped = list(map(lambda x : x[0],alpha))
        result = Counter(list(filter(lambda x : x.isalpha(),mapped)))
        
        lg.debug("result is %s" % result)
        return list(result.items())
    
        
       
            
    def list_counter(self,liist):
        """This function takes a list as input and 
        returns a dictionary with the count of each item in the list."""
        lg.debug("liist_counter is called")
        lg.debug("liist is %s" % liist)
        result = Counter(liist)
        lg.debug("result is %s" % result)
        return list(result.items())
    
    def extract(self,liist):
        """This function takes a list as input and 
        returns a list of words remove all the char expect alphabet.
        """
        lg.debug("extract is called")
        alpha = list(filter(lambda word : word.isalpha() , [''.join([j for j in word if j.isalpha()]) for word in liist]))
        lg.info("alpha is %s" % alpha)
        return alpha
    
    def extract1(self,liist):
        """This function takes a list as input and 
        returns a list of words remove all the char expect alphabet.
        """
        lg.debug("extract is called")
        alpha = list(filter(lambda word : word.isalpha() , [''.join(list(filter(lambda x : x.isalpha(),word))) for word in liist]))
        lg.info("alpha is %s" % alpha)
        return alpha
    
  
       
    
    
        
    if __name__ == "__main__":
       
       pass 
    
    
   
        