
import logger_class
import os 
import sqlite3
x = logger_class.log(os.path.abspath(__name__))
lg = x.get_logger()


class sqllite:
    
    def __init__(self, db_name):
        lg.debug("sqllite is called")
        lg.info('db_name is %s' % db_name)
        self.db_name = db_name
        self.conn = sqlite3.connect(self.db_name)
        self.cursor = self.conn.cursor()
        
    def execute_query(self, query):
        lg.info("execute_query is called")
        lg.info("query is %s" % query)
        
        self.cursor.execute(query)
        self.conn.commit()
        return self.cursor.fetchall()