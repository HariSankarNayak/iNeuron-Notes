#!/usr/bin/env python
# coding: utf-8

CLIENT_URL = "mongodb+srv://test:test@cluster0.3tlei.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
DB_NAME = "Carbon_Nanotubes_DB"
COLL_NAME = "Carbon_Nanotubes_COLL"
FILE_PATH = "carbon_nanotubes.csv"

