class NestedIterator:

    def __init__(self,given_list):
        self.given_list=given_list


    def hasNext(self):
        if len(self.given_list) > 0 and self.given_list!=[]:
            return True
        else :
            return False

    def list_handling(self,l):
        temp=""
        i=l[0]
        if type(i)==int:
            temp=i
            l.pop(0)
            if l == []:
                del self.given_list[0]
        elif type(i)==list:
            if i == []:
                del self.given_list[0]
                temp=self.list_handling(self.given_list)
            else:
                temp=self.list_handling(i)
        return temp


    def next(self):

        temp= self.list_handling(self.given_list)
        print("next()",temp)
        return temp

ni, actual = NestedIterator([[1, 1], 2, [1, 1]]), []
while ni.hasNext():
    print("ooooooooooooooo",ni.given_list)
    t=ni.next()
    actual.append(t)
    print("@@@@@@@@@@@@@@@@@@@@@@@",actual)
actual