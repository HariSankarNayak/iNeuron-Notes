import sqlite3
import log

def get_connection():
    """Establish a SQLlite3 connection returns the cursor object"""
    try:
        db = sqlite3.connect("bagofwordsset.db")
        cursor=db.cursor()
        return cursor,db
    except sqlite3.Error:
        log.error_log(f"Error Occured in DBConnection,{e}")
    except Exception as e:
        log.error_log(f"Exception Occured in DBConnection,{e}")


