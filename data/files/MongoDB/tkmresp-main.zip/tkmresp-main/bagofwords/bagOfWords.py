import os
import sqlite3

from bagofwords import log
from bagofwords import dbConnection

class bagOfWordsSet:

    filepath = os.getcwd() + "/bag_of_words_dataset"

    def __init__(self):
        self.path = bagOfWordsSet.filepath

    def get_files(self):
        """Function to fetch all the .txt files from the specified path"""
        try:
            self.files_list = []
            log.write_log("Fetching the dataset files...")
            for file in os.listdir(self.path):
                if file.endswith(".txt"):
                    self.files_list.append(file)
            log.write_log(f"Fetched and returned the dataset files...{self.files_list}")
            return self.files_list
        except Exception as e:
            log.error_log(f"Error occured while fetching the files-{e}")

    def count_all_words(self):
        """Extract all words and their respective count from all dataset files
            :return Words and the count of each word in all files"""
        try:
            count_words = dict()
            log.write_log(f"fetching the dataset files...")
            files = self.get_files()
            log.write_log(f"Fetched and returned the dataset files...{files}")
            for file in files:
                text = open(self.path + "/" + file, "rt", encoding="utf8")
                log.write_log(f"reading the file...{file}")
                data = text.read()
                words = data.split()
                for word in words:
                    if word in count_words:
                        count_words[word] = count_words[word] + 1
                    else:
                        count_words[word] = 1
                text.close()
            result = list(zip(count_words.keys(), count_words.values()))
            log.write_log(f"counted the words..Process Finished")
            # print(self.result)
            return result
        except Exception as e:
            log.error_log(f"Error occured reading datas from dataset files-{e}")


    def words_start_alpha_count(self):
        """Extract all words start with alphabets and their respective count from all dataset files
            :return alphabet and the count of each word start with the resp. alphabet in all files"""
        try:
            count_words = dict()
            log.write_log(f"Extracting the words from dataset files")
            words_list = self.count_all_words()
            for words in words_list:
                if words[0].isalpha():
                    if words[0][0] in count_words:
                        count_words[words[0][0]] = count_words[words[0][0]] + words[1]
                    else:
                        count_words[words[0][0]] = words[1]

            result = list(zip(count_words.keys(), count_words.values()))
            log.write_log(f"Finished Process")
            return result
        except Exception as e:
            log.error_log(f"Error occured counting alphabets from dataset files-{e}")

    def splchars_remove_words(self):
        """Remove special chars from words and extract the words from all dataset files"""
        try:
            count_words = []
            log.write_log(f"Extracting the words from dataset files")
            words_list = self.count_all_words()
            for word in words_list:
                only_alpha = ""
                for char in word[0]:
                    if char.isalpha():
                        only_alpha += char
                if only_alpha:
                    count_words.append(only_alpha)
            log.write_log(f"Finished Process")
            return count_words
        except Exception as e:
            log.error_log(f"Error occured reading special characters from dataset files-{e}")

    def map_of_all_dataset(self):
        "Map datas from all dataset files and insert the result into the Database SQLite3"
        try:
            log.write_log("Fetching the dataset files...")
            files = self.get_files()
            log.write_log(f"Fetched and returned the dataset files...")
            result = []
            for file in files:
                words_list = []
                text = open(self.path + "/" + file, "rt", encoding="utf8")
                data = text.read()
                log.write_log(f"reading the file...{file}")
                words = data.split()
                for word in words:
                    words_list.append(word)
                result.append(words_list)
                text.close()
            exp = "zip("
            for i in result:
                exp += f'{i},'
            exp += ')'
            output = eval(exp)
            # output=list(reduce(zip,words_list))
            log.write_log(f"Connecting to the SQLlite3 Database....")
            cursor,db = dbConnection.get_connection()
            #cursor.execute('drop table if exists bag_of_words ')
            cursor.execute(f'create table IF NOT EXISTS bag_of_words(mapped_words text)')
            log.write_log(f"Table Created")
            sql_query=""
            for i in output:
                s=str(i)
                sql = "insert into bag_of_words values(?)"
                cursor.execute(sql, (s,))
            log.write_log(f"Records Inserted - {cursor.lastrowid}")
            db.commit()
            cursor.execute(f"select count(*) from bag_of_words")
            log.write_log(f" Records are - {cursor.fetchall()}")
            cursor.close()
        except sqlite3.Error as e:
            db.rollback()
            log.error_log(f"Error occured inserting datas from dataset files to sqllite3 {e}")
        except Exception as e:
            log.error_log(f"Error occured inserting datas from dataset files to sqllite3 {e}")

if __name__ == '__main__':
    b = bagOfWordsSet()

    # result=b.count_all_words()

    # result=b.words_start_alpha_count()

    result=b.splchars_remove_words()
    
    print(result)

    #b.map_of_all_dataset()
