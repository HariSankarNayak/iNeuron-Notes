bagOfWords.py - first file to run
                 - has all the tasks modules
                    1.count_all_words - extract all words from dataset files and their resp. count
                    2.words_start_alpha_count - return the count of words start with the same alphabets
                        from all files(dataset)
                    3.splchars_remove_words - remove spl chars and from datas and extract the words
                    4.mapping the datas of all files with each other
                        and dumping the mapped result to SQLlite3 DB

dbConnection.py - Source for db connection
log.py -- source for logging
log directory -  the log file is stored
bags_of_words_dataset directory -- all dataset('.txt') files are stored
bagofwordsset.db--created database,where the mapped records are dumped