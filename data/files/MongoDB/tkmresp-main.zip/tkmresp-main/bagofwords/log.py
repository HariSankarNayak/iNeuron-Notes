import os
import logging as log
log.basicConfig(filename=f'{os.getcwd()}/log/bagofwords.log', level=log.DEBUG,
                format='%(asctime)s %(levelname)s %(message)s')

def write_log(msg):
    log.debug(msg)

def error_log(msg):
    log.exception(msg)
