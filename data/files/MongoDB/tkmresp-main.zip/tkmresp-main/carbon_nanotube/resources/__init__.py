from carbon_nanotube.resources import csvToMongodb as obj
from carbon_nanotube.resources import log
from carbon_nanotube.resources import dbConnection as db

class mongoDB_Data_Handler:

    def __init__(self):
        self.cursor = db.get_connection()

    def csvtodb(self):
        """Load datas from carbonnanotubes.csv to MongoDB carbonnanotube database"""
        log.write_log(f"CSV file data to MongoDb called")
        obj.csvToMongodb()

    def insert_data(self):
        """Insert datas to mongodb database """
        dict1={
        "nVector": "200",
        "mVector": "100",
        "initCoord_u": "0,10000",
        "initCoord_v": "0,10000",
        "initCoord_w": "0,10000",
        "calcCoord_u": "0,10000",
        "calcCoord_v": "0,10000",
        "calcCoord_w": "0,10000"
        }
        try :
            log.write_log(f"Inserting Data {dict1}")
            result=self.cursor.insert_one(dict1)
            log.write_log(f"Inserted {result.inserted_id}!!")
        except Exception as e:
            log.error_log(f"Exception Occured in Inserting the data,{e}")

    def update_data(self):
        """Update datas in mongodb"""
        try:
            log.write_log(f"Updating Data")
            result=self.cursor.update_many({"nVector": "200"}, {"$set": {"nVector": "2"}})
            log.write_log(f"Data Updated !! {result.modified_count}")
        except Exception as e:
            log.error_log(f"Exception Occured in Updating the data,{e}")

    def find_data(self):
        """Find specified datas in mongodb """
        try:
            log.write_log(f"Finding Data")
            result=self.cursor.find({"mVector":"100"})
            for i in result:
                #print(i)
                log.write_log(f"Found Data {i}")
        except Exception as e:
            log.error_log(f"Exception Occured in finding the data,{e}")


    def delete_data(self):
        """Delete specified Data(s) in mongodb"""
        try:
            log.write_log(f"Deleting Data")
            result = self.cursor.delete_many({"mVector": "100"})
            log.write_log(f"Deleted Data {result.deleted_count}")
        except Exception as e:
            log.error_log(f"Exception Occured in Deleting the data,{e}")

d=mongoDB_Data_Handler()
d.csvtodb()
#d.insert_data()
#d.update_data()
#d.find_data()
#d.delete_data()