import json
from carbon_nanotube.resources import log
class JSONtoMongoDb:
    @staticmethod
    def load_data(jsonFilePath,coll1):
        """Loads datas from JSON file and dumps to MongoDB
        :parameter jsonFilePath --path of the json file
                    coll1 --- mongodb cursor object
        """
        try:
            log.write_log(f"Called load_data method")
            with open(jsonFilePath) as file:
                file_data = json.load(file)

            # Inserting the loaded data in the Collection
                coll1.insert_many(file_data)

            log.write_log(f"Inserted data into mongodb")
        except Exception as e:
            log.error_log(f"Exception Occured in getDBconn module,{e}")


