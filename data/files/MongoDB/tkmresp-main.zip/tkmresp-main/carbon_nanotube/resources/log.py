import os
import logging as log
path = os.path.abspath(os.path.join(os.getcwd(), os.pardir))
log.basicConfig(filename=f'{path}/log/carbon_nanotube.log', level=log.DEBUG,
                format='%(asctime)s %(levelname)s %(message)s')
print(path)
def write_log(msg):
    log.debug(msg)

def error_log(msg):
    log.exception(msg)
