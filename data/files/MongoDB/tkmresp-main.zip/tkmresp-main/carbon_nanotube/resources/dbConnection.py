import logging
import pymongo
from carbon_nanotube.resources import log

def get_connection():
    """Establish a MongoDb connection returns the cursor object"""
    try:
        client = pymongo.MongoClient("mongodb+srv://mongodb:mongodb@cluster0.5ooxp.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
        db=client["carbannanotubedb"]
        collection=db["carbonNanoTubes"]
        return collection
    except Exception as e:
        log.error_log(f"Exception Occured in DBConnection,{e}")
