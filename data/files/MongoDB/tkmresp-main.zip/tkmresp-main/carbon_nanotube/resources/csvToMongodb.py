import os
from carbon_nanotube.resources import log
from carbon_nanotube.resources.csvtojson import csvtojson as cj
from carbon_nanotube.resources import dbConnection as conn
from carbon_nanotube.resources.jsontomongodb import JSONtoMongoDb as jdb

class csvToMongodb:
    """Reads and dumps  the data from csv file to MongoDB"""
    abs_path = os.path.abspath(os.path.join(os.getcwd(), os.pardir))
    csvFilePath = abs_path + "\dataset\carbonnanotubes.csv"
    jsonFilePath = abs_path + "\json\carbonnanotubes.json"
    try:
        def __init__(self):
            log.write_log(f"csvToMongodb instantiated")
            self.csvFilePath = csvToMongodb.csvFilePath
            self.jsonFilePath = csvToMongodb.jsonFilePath
            # converting csv to json
            self.json()
            self.coll1=self.getDBconn()
            self.jsonToMongo()

        def json(self):
            """Create a json file with the csv file datas"""
            log.write_log(f"Called json method{csvToMongodb}")
            cj.createjson(self.csvFilePath,self.jsonFilePath)
            log.write_log(f"Load data from CSV to JSON file successfully")

        def getDBconn(self):
            """Get the DB connection"""
            try:
                log.write_log(f"Connecting Database...")
                # dump json data to mongodb
                # 1.establishing mongodb connection
                coll1 = conn.get_connection()
                log.write_log(f"Database Connected {coll1}")
                return coll1
            except Exception as e:
                log.error_log(f"Exception Occured in getDBconn module,{e}")

        def jsonToMongo(self):
            """Json data  to Mongodb"""
            jdb.load_data(self.jsonFilePath, self.coll1)
            log.write_log(f"Imported Datas from Json to MongoDB ")


    except Exception as e:
        log.error_log(f"Exception Occured in csvToMongodb module,{e}")
