import csv
import json
import carbon_nanotube.resources.log as log
class csvtojson:

    @staticmethod
    def createjson(csvFilePath,jsonFilePath):
        """Create JSON file from CSV file"""
        try:
            log.write_log(f"Called json method")
            jsonArray = []
            log.write_log(f"Opening csv file {csvFilePath}")
            with open(csvFilePath, encoding='utf-8') as csvf:

            #load csv file data using csv library's dictionary reader
                csvReader = csv.DictReader(csvf,delimiter=";")

                #add this python dict to json array
                #changing the dict keys to mongodb conventional column names
                column = ["nVector", "mVector", "initCoord_u", "initCoord_v", "initCoord_w", "calcCoord_u", "calcCoord_v",
                      "calcCoord_w"]
                for row in csvReader:
                    count = 0
                    for i in row.copy():
                        row[column[count]] = row.pop(i)
                        count += 1
                    jsonArray.append(row)
                # add this python dict values to json array,no change in column names
                #for row in csvReader:
                #   jsonArray.append(row)
                #convert python jsonArray to JSON String and write to file
                    log.write_log(f"Writing to Json file {jsonFilePath} ,row {count}")
                    with open(jsonFilePath, 'w', encoding='utf-8') as jsonf:
                        jsonString = json.dumps(jsonArray, indent=4)
                        jsonf.write(jsonString)

        except FileNotFoundError:
            msg = "Sorry, the file "+ csvFilePath + "does not exist."
            log.error_log(msg)
        except Exception as e:
            log.error_log(f"Exception Occured in CSVtoJson module,{e}")


