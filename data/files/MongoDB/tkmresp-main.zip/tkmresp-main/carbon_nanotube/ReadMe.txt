All source files are in carbon_nanotube/resource directory
log file is created in carbon_nanotube/log
csv file - carbon_nanotube/dataset
resource/__init__.py - file to run first.Have all the function calls.
