
from Log.logger import log
import os 
import sqlite3
x = log(os.path.basename(__name__))
lg = x.get_logger()


class sqllite:
    
    def __init__(self, db_name):
        
        lg.debug("sqllite is called")
        lg.info('db_name is %s' % db_name)
        self.db_name = db_name
        self.conn = sqlite3.connect('DB/'+self.db_name)
        self.cursor = self.conn.cursor()
        
    def execute_query(self, query):
        """execute query"""
        lg.info("execute_query is called")
        lg.info("query is %s" % query)
        
        self.cursor.execute(query)
        self.conn.commit()
        return self.cursor.fetchall()
    
    def create_table(self, table_name, column_name):
        """create table"""
        lg.info("create_table is called")
        lg.info("table_name is %s" % table_name)
        lg.info("column_name is %s" % column_name)
        query = "CREATE TABLE %s (%s)" % (table_name, column_name)
        lg.info("query is %s" % query)
        self.cursor.execute(query)
        self.conn.commit()
        return True
    
    def insert_data(self, table_name, data):
        """_insert_data"""
        
        lg.info("insert_data is called")
        lg.info("table_name is %s" % table_name)
        lg.info("data is %s" % str(data))
        query = "INSERT INTO {} VALUES {}" .format(table_name, data)
        lg.info("query is %s" % query)
        self.cursor.execute(query)
        self.conn.commit()
        return True
    
    def get_data(self, table_name):
        """get data"""
        lg.info("get_data is called")
        lg.info("table_name is %s" % table_name)
        query = "SELECT * FROM %s" % table_name
        lg.info("query is %s" % query)
        self.cursor.execute(query)
        return self.cursor.fetchall()
    
    def get_data_with_condition(self, table_name, condition):
        """get data with condition"""
        lg.info("get_data_with_condition is called")
        lg.info("table_name is %s" % table_name)
        lg.info("condition is %s" % condition)
        query = "SELECT * FROM %s WHERE %s" % (table_name, condition)
        lg.info("query is %s" % query)
        self.cursor.execute(query)
        return self.cursor.fetchall()
    
    def update_table(self, table_name, column_name, condition):
        """update table"""
        lg.info("update_table is called")
        lg.info("table_name is %s" % table_name)
        lg.info("column_name is %s" % column_name)
        lg.info("condition is %s" % condition)
        query = "UPDATE %s SET %s WHERE %s" % (table_name, column_name, condition)
        lg.info("query is %s" % query)
        self.cursor.execute(query)
        self.conn.commit()
        return True
    
    def delete_data(self, table_name, condition):
        """delete data"""
        lg.info("delete_data is called")
        lg.info("table_name is %s" % table_name)
        lg.info("condition is %s" % condition)
        query = "DELETE FROM %s WHERE %s" % (table_name, condition)
        lg.info("query is %s" % query)
        self.cursor.execute(query)
        self.conn.commit()
        return True
    
    def drop_table(self, table_name):
        """drop table"""
        lg.info("drop_table is called")
        lg.info("table_name is %s" % table_name)
        query = "DROP TABLE %s" % table_name
        lg.info("query is %s" % query)
        self.cursor.execute(query)
        self.conn.commit()
        return True
    
    
    def close_connection(self):
        """close connection"""
        lg.info("close_connection is called")
        self.conn.close()
        lg.info("connection is closed")
        return True
    
    