from Log.logger import log
from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider
from cassandra.query import SimpleStatement, BatchStatement


import os 
from configparser import ConfigParser

config = ConfigParser()
config.read('config.ini')

x = log(os.path.basename(__name__))
lg = x.get_logger()


cloud_config= {
        'secure_connect_bundle': config['cassandra']['secure_connect_bundle'],
}
auth_provider = PlainTextAuthProvider(config.get('cassandra','clientid' ), config.get('cassandra','clientsceret'))

class cassandra:
    
    """class for cassandra operation"""
    def __init__(self,keyspace_name):
        try:
            self.cluster = Cluster(cloud=cloud_config, auth_provider=auth_provider)
            self.keyspace = keyspace_name
            self.session = self.cluster.connect(keyspace_name)
            lg.debug('Cassandra connection established')
        except Exception as e:
            lg.error('Error in cassandra_operation.py: {}'.format(e))
        
    
    
    
    def create_table(self,keyspace_name  ,table_name,column_name):
        """This function creates table

        Args:
            keyspace_name (key_space): keyspace name where tp create a table
            table_name (string): table name to create
            column_name (string ): string of column names

        Returns:
            Boolen : True if table created else False
            
            eg : 
            
            column_list = "id int,Chiralindicen text , Chiralindicem text,primary key(id)"
            cas.create_table("CarbonNano","carbon_nanotubes", column_list)
        """       
        try:
            self.session = self.cluster.connect(keyspace_name)
            lg.debug('Connected to keyspace {}'.format(keyspace_name))
            query = "create table if not exists {} ({})".format(table_name,column_name)
            lg.debug('Query: {}'.format(query))
            self.session.execute(query)
            lg.debug('Table created')
        except Exception as e:
            lg.error('Error in cassandra_operation.py: {}'.format(e))
            return -1
        return True
    
    def insert_data(self,keyspace_name,table_name,column_name,data):
        """This function creates table

        Args:
            keyspace_name (key_space): keyspace name where the data to be inserted
            
            table_name (string): table name to create
            column_name (string ): string of column names
            data (tuple) : data to be inserted

        Returns:
            Boolen : True if table created else False
            
            eg : 
            
            column_list = "id int,Chiralindicen text , Chiralindicem text,primary key(id)"
            cas.insert_data('CarbonNano', 'carbon_nanotubes', column_list, tuple(data))
        """ 
        try:
            self.session = self.cluster.connect(keyspace_name)
            lg.debug('Connected to keyspace {}'.format(keyspace_name))
            query = "insert into {} ({}) values {}".format(table_name,column_name,data)
            lg.debug('Query: {}'.format(query))
            self.session.execute(query)
            lg.debug('Data inserted')
        except Exception as e:
            lg.error('Error in cassandra_operation.py: {}'.format(e))
            return -1
        return True
    
    def get_data(self,keyspace_name,table_name):
        """Function gets all data from  table with out conditions

        Args:
            keyspace_name (string): keyspace name FROM WHERE TO GET data 
            table_name (string): table name FROM WHERE TO GET data

        Returns:
            Boolean : True if table created else False
        """        
        try:
            self.session = self.cluster.connect(keyspace_name)
            lg.debug('Connected to keyspace {}'.format(keyspace_name))
            query = "select * from {}".format(table_name)
            lg.debug('Query: {}'.format(query))
            result = self.session.execute(query)
            lg.debug('Data fetched')
        except Exception as e:
            lg.error('Error in cassandra_operation: {}'.format(e))
            return -1
        return result
    
    def get_data_with_condition(self,keyspace_name,table_name,column_name,condition):
        """Function gets all data from  table with out conditio

        Args:
            keyspace_name (string): keyspace name FROM WHERE TO GET data 
            table_name (string): table name FROM WHERE TO GET data
            condition (string): condition to get data

        Returns:
            Boolean : True if table created else False
        """ 
        
        try:
            self.session = self.cluster.connect(keyspace_name)
            lg.debug('Connected to keyspace {}'.format(keyspace_name))
            query = "select {} from {} where {}".format(column_name ,table_name,condition)
            lg.debug('Query: {}'.format(query))
            result = self.session.execute(query)
            lg.debug('Data fetched')
        except Exception as e:
            lg.error('Error in cassandra_operation: {}'.format(e))
            return -1
        return result
    
    def update_data(self,keyspace_name,table_name,data,condition):
        """Function updates all data from  table with condition

        Args:
            keyspace_name (string): keyspace name FROM WHERE TO update data 
            table_name (string): table name FROM WHERE TO update data 
            condition (string): condition to update data

        Returns:
            Booleen : True if table created else False
        """ 
        try:
            self.session = self.cluster.connect(keyspace_name)
            lg.debug('Connected to keyspace {}'.format(keyspace_name))
            query = "update {} set {} where {}".format(table_name,data,condition)
            lg.debug('Query: {}'.format(query))
            self.session.execute(query)
            lg.debug('Data updated')
        except Exception as e:
            lg.error('Error in cassandra_operation: {}'.format(e))
            return -1
        return True
    
    def excute_query(self,keyspace_name,query):
        """Function excutes query

        Args:
            keyspace_name (string): keyspace name FROM WHERE TO excute the data 
            query (_type_): query to excute

        Returns:
            Boolean : True if table created else False
        """        
        
        try:
            self.session = self.cluster.connect(keyspace_name)
            lg.debug('Connected to keyspace {}'.format(keyspace_name))
            lg.debug('Query: {}'.format(query))
            result = self.session.execute(query)
            lg.debug('Data fetched')
        except Exception as e:
            lg.error('Error in cassandra_operation: {}'.format(e))
            return -1
        return result
    
    def batch(self,keyspace,batch_statement):
        """_summary_

        Args:
            keyspace (_type_): _description_
            batch_statement (_type_): _description_

        Returns:
            _type_: _description_
        """        
        try:
            lg.debug('Batch statement: {}')
            self.session = self.cluster.connect(keyspace)
            self.session.execute(batch_statement)
            lg.debug('Batch executed')
        except Exception as e:
            lg.error('Error in cassandra_operation: {}'.format(e))
            return -1
        return True
    
    def close_connection(self):
        """close connection"""
        self.cluster.shutdown()
        lg.debug('Connection closed')
    
    
    
    
    
    if __name__ == '__main__':
        pass
            
    