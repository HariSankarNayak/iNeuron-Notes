
from Log.logger import log
import os 
import pymongo
from configparser import ConfigParser


config = ConfigParser()
config.read('config.ini')


x = log(os.path.basename(__name__))
lg = x.get_logger()

class mongodb:
    '''class for mongo db operations'''
    def __init__(self,db, collection):
        """Initialize the class with the database name and collection name
        the class initialization the class with the below argument 

        Args:
            db : database name
            collection : collection name
            
        """
        
        lg.debug('init function db %s collection %s', db, collection)
        self.db = db
        self.collection = collection

    def get_connection(self):
        """ This function will return the connection to the mongo db
        to the database with the initial parameters self.db and self.collection

        Returns:
            True if connection is successful 
        """
        lg.debug('get connection to mongo db')
        try:
            self.conn = pymongo.MongoClient(config.get("mongodb_url","url"))
            lg.debug('connection to mongo db successful')
            self.db = self.conn[self.db]
            self.collection = self.db[self.collection]
        except Exception as e:
            lg.error('error in get connection to mongo db %s', e)
            return False
        lg.debug('connection to mongo db successful')
        return True
    
    def checkExistence_DB(self,DB_NAME):
        """"It verifies the existence of database name
        DB_NAME: database name 
        return True if database exists else False"""
        
        DBlist = self.conn.list_database_names()
        if DB_NAME in DBlist:
            lg.debug(f"DB: '{DB_NAME}' exists")
            return True
        lg.error(f"DB: '{DB_NAME}' not yet present OR no collection is present in the DB")
        return False
    
    def checkExistence_COL(self,COLLECTION_NAME):
        
        """It verifies the existence of collection name
        Collection_NAME: collection name
        returns True if collection exists else False"""
        
        collection_list = self.db.list_collection_names()
    
        if COLLECTION_NAME in collection_list:
            lg.debug(f"Collection:'{COLLECTION_NAME}' in Database:'' exists")
            return True
    
        lg.error(f"Collection:'{COLLECTION_NAME}' in Database:' does not exists OR \n\
        no documents are present in the collection")
        return False
    
    
    def get_databases(self):
        '''This function will return the list of databases'''
        lg.debug('get database')
        return self.conn.list_database_names()

    def insert_one(self, data):
        """insert one data into mongo dd

        Args:
            data (formated ): data to be inserted into mongo db
            
            {Key : Value}
            

        Returns:
            True if insertion is successful else False
        """
        try:
            self.collection.insert_one(data)
        except Exception as e:
            lg.debug('error in insert data into mongo db %s', e)
            return False
        lg.debug('insert data into mongo db successful%s', data)
        return True

    def insert_many(self, data):
        """insert many data into mongo dd

        Args:
            data (formated ): data to be inserted into mongo db
            
            {Key : Value}
            

        Returns:
            True if insertion is successful else False
        """
        lg.debug('insert many data into mongo db')
        try:
            self.collection.insert_many(data)
        except Exception as e:
            lg.critical('error in insert many data into mongo db %s', e)
            print(e)
            return False
        lg.debug('insert many data into mongo db successful')
        return True

    def find_one(self, query={}):
        """find one data from mongo db
        if query is not provided then it will return the first document
        """
        
        lg.debug('find one data from mongo db')
        try:
            return self.collection.find_one(query)
        except Exception as e:
            lg.critical('error in find one data from mongo db %s', e)
            return False

    def find_many(self, query={}, limit=200):
        """find many data from mongo db
        if query is not provided then it will return all the documents
        """
    
        try:
            lg.debug('find many data from mongo db')
            return self.collection.find(query).limit(limit)
        except Exception as e:
            lg.critical('error in find many data from mongo db %s', e)
            return False

    def update_one(self, query, data):
        """update one data from mongo db

        Args:
            query (Arg): Arguments to be matched
            data (formated): data to be updated

        Returns:
            _True if update is successful else False
        """
        
        try:
            lg.debug('update one data from mongo db query %s data %s', query, data)
            self.collection.update_one(query, data)
        except Exception as e:
            lg.critical('error in update one data from mongo db %s', e)
            return False
        lg.debug('update one data from mongo db successful')
        return True


    def update_many(self, query, data):
        """update many data from mongo db
        Args:
            query (Arg): Arguments to be matched
            data (formated): data to be updated

        Returns:
            True if update is successful else False
        """
        try:
            lg.debug('update many data from mongo db query %s data %s', query, data)
            self.collection.update_many(query, data)
        except Exception as e:
            lg.critical('error in update many data from mongo db %s', e)
            return False
        lg.debug('update many data from mongo db successful')
        return True
    
    
    def delete_one(self, query):
        """delete one data from mongo db
        Args:
            query (Arg): Arguments to be matched
    
        Returns:
            True if delete is successful else False
        """
        try:
            lg.debug('delete one data from mongo db query %s', query)
            self.collection.delete_one(query)
        except Exception as e:
            lg.critical('error in delete one data from mongo db %s', e)
            return False
        lg.debug('delete one data from mongo db successful')
        return True
    
    def delete_many(self, query):
        """delete many data from mongo db
        Args:
            query (Arg): Arguments to be matched
           

        Returns:
            True if delete is successful else False"""
        try:
            lg.debug('delete many data from mongo db query %s', query)
            self.collection.delete_many(query)
        except Exception as e:
            lg.critical('error in delete many data from mongo db %s', e)
            return False
        lg.debug('delete many data from mongo db successful')
        return True
    
    def drop_collection(self, collection):
        """drop collection from mongo db
        Args:
            Collection: collection name to be dropped
           
        Returns:
            True if drop is successful else False"""
            
        if self.checkExistence_COL(collection):
            lg.debug('drop collection found in DB')
            try:
                lg.debug('drop collection from mongo db')
                self.collection = self.db[collection]
                self.collection.drop()
            except Exception as e:
                lg.critical('error in drop collection from mongo db %s', e)
                return False
            lg.debug('drop collection from mongo db successful')
            return True
        else:
            lg.error('collection not present in the database')
            return 'collection not present in the database'
        
    def drop_database(self, db):
        """drop database from mongo db
        Args:
            Collection: database name to be dropped
           
        Returns:
            True if drop is successful else False
        """
        if self.checkExistence_DB(db):
            lg.debug('drop database found in DB')
            try:
                lg.debug('drop database from mongo db')
                self.conn.drop_database(db)
            except Exception as e:
                lg.critical('error in drop database from mongo db %s', e)
                return False
            lg.debug('drop database from mongo db successful')
            return True
        else:
            lg.error('database not present in the database')
            return 'database not present in the database'
        
    def close_connection(self):
        '''close connection with mongo db'''
        lg.debug('close connection with mongo db')
        try:
            self.conn.close()
        except Exception as e:
            lg.critical('error in close connection with mongo db %s', e)
            return False
        lg.debug('close connection with mongo db successful')
        return True
    
    
    if __name__ == '__main__':
        pass
    
    
    
    