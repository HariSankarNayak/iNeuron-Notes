


import mysql.connector
from Log.logger import log
import os 
from configparser import ConfigParser


config = ConfigParser()
config.read('config.ini')

x = log(os.path.basename(__name__))
lg = x.get_logger()


class sql_operation():
    """class for mySql operation"""
    def __init__(self):
        try:
            
            self._host = config.get('mysql', 'host')
            self._user = config.get('mysql', 'user')
            self._password = config.get('mysql', 'password')
            self.database = None
            self.conn = None
            self.cursor = None
        except Exception as e:
            lg.error('error in init %s', e)
            raise e
        

    def connect(self):
        """connect to database"""
        try:
            self.conn = mysql.connector.connect(host=self._host,
                                                user=self._user,
                                                password=self._password,use_pure=True)
        except Exception as e:
            lg.error("Connection Failed %s",e)
            return False
        lg.debug("Connection Successful")
        return True
    
    def get_cur(self):
        """get cursor"""
        if self.conn is None:
            lg.error("Connection is None")
            return False
        self.cursor = self.conn.cursor()
        lg.debug("Cursor is created")
        return True
    
    def get_database_list(self):
        """get database list"""
        try:
            self.get_cur()
            self.cursor.execute("SHOW DATABASES")
            lg.debug("database list is fetched")
            return self.cursor.fetchall()
        except Exception as e:
            lg.error("error in get_database_list %s",e)
            return False
    
    def get_table_list(self, database):
        """get table list"""
        try:
            self.get_cur()
            self.cursor.execute("SHOW TABLES FROM {}".format(database))
            lg.debug("table list is fetched")
            return self.cursor.fetchall()
        except Exception as e:
            lg.error("error in get_table_list %s",e)
            return False
    
    def get_column_list(self, database, table):
        """get column list"""
        try:
            self.get_cur()
            self.cursor.execute("SHOW COLUMNS FROM {}.{}".format(database, table))
            lg.debug("column list is fetched, %s %s", database, table)
            return self.cursor.fetchall()
        except Exception as e:
            lg.error("error in get_column_list %s",e)
            return False
    
    def get_data(self, database, table, column, condition):
        """get data"""
        try:
            self.get_cur()
            self.cursor.execute("SELECT {} FROM {}.{} WHERE {}".format(column, database, table, condition))
            lg.debug("data is fetched %s %s %s %s", database, table, column, condition)
            return self.cursor.fetchall()
        except Exception as e:
            lg.error("error in get_data %s",e)
            return False
        
    def get_data_without_condition(self, database, table):
        """get data with out condition"""
        try:
            self.get_cur()
            self.cursor.execute("SELECT * FROM {}.{}".format( database, table))
            lg.debug("data is fetched %s %s ", str(database), table)
            return self.cursor.fetchall()
        except Exception as e:
            lg.error("error in get_data %s",e)
            return False

    def create_database(self, database):
        """create database"""
        try:
            self.get_cur()
            self.cursor.execute("CREATE DATABASE {}".format(database))
            self.conn.commit()
            lg.debug("database is created %s", database)
            return True
        except Exception as e:
            lg.error("error in create_database %s",e)
            return False
    
    def create_table(self, database, table, column_list):
        """create table"""
        try:
            self.get_cur()
            self.cursor.execute("CREATE TABLE {}.{} ({})".format(database, table, column_list))
            self.conn.commit()
            lg.debug("table is created %s %s %s", database, table, column_list)
            return True
        except Exception as e:
            lg.error("error in create_table %s",e)
            return False
        
    def insert_data(self, database, table,  value_list):
        """insert data"""
        try:
            lg.debug("data is inserted %s %s %s ", database, table, str(value_list))
            self.cursor.execute("INSERT INTO {}.{} VALUES {}".format(database, table, value_list))
            self.conn.commit()
            
            return True
        except Exception as e:
            lg.error("error in insert_data %s",e)
            return False
        
    def update_data(self, database, table, column_list, condition):
        """update data"""
        try:
            self.get_cur()
            self.cursor.execute("UPDATE {}.{} SET {} WHERE {}".format(database, table, column_list, condition))
            self.conn.commit()
            lg.debug("data is updated %s %s %s %s", database, table, column_list, condition)
            return True
        except Exception as e:
            lg.error("error in update_data %s",e)
            return False
        
    def delete_data(self, database, table, condition):
        """delete data"""
        try:
            self.get_cur()
            self.cursor.execute("DELETE FROM {}.{} WHERE {}".format(database, table, condition))
            self.conn.commit()
            lg.debug("data is deleted %s %s %s", database, table, condition)
            return True
        except Exception as e:
            lg.error("error in delete_data %s",e)
            return False
        
        
    def drop_table(self, database, table):
        """drop table"""
        try:
            self.get_cur()
            self.cursor.execute("DROP TABLE if exists {}.{}".format(database, table))
            self.conn.commit()
            lg.debug("table is dropped %s %s", database, table)
            return True
        except Exception as e:
            lg.error("error in drop_table %s",e)
            return False
        
    def drop_database(self, database):
        """drop database"""
        try:
            self.get_cur()
            self.cursor.execute("DROP DATABASE if exists {}".format(database))
            self.conn.commit()
            lg.debug("database is dropped %s", database)
            return True
        except Exception as e:
            lg.error("error in drop_database %s",e)
            return False
    
    
    
    
    
    
    
    
    
    
            

    